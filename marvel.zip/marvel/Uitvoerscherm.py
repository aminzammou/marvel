from tkinter import *
import tkinter as tk
from tkinter import messagebox
from Tkinter import *
from marvel import *

naam = rasuper()
x=0
z=0
punten=25
uitslag = 0
def hint():
    global x
    hint.counter+=1
    L['text'] = 'Aantal Hints ' + str(hint.counter)
    x=hint.counter
    x=x*-3
    aantalPunten = punten+x-z
    hoeveelPunten['text'] = 'Aantal punten: ' + str(aantalPunten)
    return x

def raden():
    global z
    if naam == antwoord.get():
        global uitslag
        h= int(punten+x-z)
        uitslag+=h
        aantalPunten = punten+x-z
        hoeveelPunten['text'] = 'Aantal punten: ' + str(aantalPunten)
        puntenBijElkaar['text'] = 'Totaal antal punten: ' + str(uitslag)
        uitslag=0

        MsgBox = tk.messagebox.askquestion('Exit Application', 'Goed geraden!,Wilt u opnieuw spelen?', icon='warning')
        if MsgBox == 'no':
            window.destroy()
        else:
            tk.messagebox.showinfo('Return', 'Het nieuwe spel word gestart')

    else:
        raden.counter +=1
        R['text'] = 'Aantal fout geraden: ' + str(raden.counter)
        z=raden.counter
        aantalPunten = punten+x-z
        hoeveelPunten['text'] = 'Aantal punten: ' + str(aantalPunten)
        return z
def hinten():
    allehints = hints()
    for hin in allehints:
        command['text'] = hin
def close_window ():
    window.destroy()
    print(uitslag)

def gemengdh():
    hint()
    for hinnnn in hinten():
        hinnnn
def gemengda():
    raden()
    # antwoorden()
window = Tk()
hint.counter = 0
raden.counter=0

C = Canvas(window, bg="blue", height=250, width=300)
filename = PhotoImage(file = "monkimage.png")
background_label = Label(window, image=filename)
background_label.place(x=0, y=0, relwidth=1, relheight=1)

C.pack()


antwoord = Entry(master=window)
antwoord.pack(padx=20,pady=20)

hulp= Button(window, text="Hint", command = gemengdh)
hulp.pack(padx=20,pady=20)

gok = Button (window, text = "Raden", command = gemengda)
gok.pack(padx=20,pady=20)

L = Label(window, text="Aantal hints:")
L.pack(padx=20,pady=20)

R = Label(window, text="Aantal keer fout geraden:")
R.pack(padx=20,pady=20)

command = Label(window, text="")
command.pack(padx=20,pady=20)

hoeveelPunten = Label(window, text="Aantal punten:")
hoeveelPunten.pack(padx=20,pady=20)

puntenBijElkaar = Label(window, text="Totaal aantal punten:")
puntenBijElkaar.pack(padx=20,pady=20)

afsluiten = Button (window, text = "Good-bye.", command = close_window)
afsluiten.pack(padx=20,pady=20)

window.mainloop()